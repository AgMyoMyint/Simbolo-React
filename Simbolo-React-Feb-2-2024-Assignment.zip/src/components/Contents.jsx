import React from 'react'

const Contents = () => {
  return (
    <h1>Contents</h1>
  )
}

export default Contents